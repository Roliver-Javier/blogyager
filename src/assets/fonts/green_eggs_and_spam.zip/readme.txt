TrueTypeFont: Green Eggs and Spam (Regular and Outline)
Dennis Ludlow 2015 all rights reserved
Sharkshock Productions
dennis@sharkshock.net


Try it! Try it! You will see! A font that's fun for you and me. Boys and Girls, Ladies and Gentlemen i give you Green Eggs and Spam; A playful typeface that will take you back to your childhood
before you can say "Sam I Am." This typeface contains accents, European characters, and kerning. Perfect for scrapbooking and children's books. Green Eggs and Spam comes in two different 
versions: Regular and Outline. Email me if you need Eastern European characters.


For commercial use please contact me at dennis@sharkshock.net to discuss an end user license. I also design custom fonts for businesses, logos, and many other things. 
visit www.sharkshock.net for more and take a bite out of BORING design!

